﻿namespace ASP_MVC_Slutuppgift.Views.Account;

public class UserPageVM
{
    public string Username { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string? Temp { get; set; }

}
