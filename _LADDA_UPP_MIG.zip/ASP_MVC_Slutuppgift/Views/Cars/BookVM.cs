﻿namespace ASP_MVC_Slutuppgift.Views.Cars;

public class BookVM
{
}
